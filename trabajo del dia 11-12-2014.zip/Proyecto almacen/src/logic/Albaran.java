package logic;

public class Albaran {

	private int id;
	private String codigo;
	private String destino;
	private String fecha;
	private Pedido pedido;
	
	public Albaran(int id, String codigo, String destino, String fecha,
			Pedido pedido) {
		super();
		this.id = id;
		this.codigo = codigo;
		this.destino = destino;
		this.fecha = fecha;
		this.pedido = pedido;
	}
	
	public int getId() {
		return id;
	}
	public String getCodigo() {
		return codigo;
	}
	public String getDestino() {
		return destino;
	}
	public String getFecha() {
		return fecha;
	}
	public Pedido getPedido() {
		return pedido;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}
	
}
