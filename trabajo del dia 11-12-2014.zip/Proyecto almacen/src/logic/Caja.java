package logic;

public class Caja {
	
	private int id;
	private String pegatina;
	private int idProducto;
	private int cantidad;
	
	public Caja(ProductoPedido producto) {
		this.idProducto = producto.getId_Producto();
		this.cantidad = producto.getCantidad();
		this.pegatina = generarPegatina(producto);
	}

	private String generarPegatina(ProductoPedido producto) {
		return "" + producto.getId_Pedido() + "0" + producto.getId_Producto() 
				+ "" + producto.getCantidad() + "0";
	}

	public int getId() {
		return id;
	}

	public String getPegatina() {
		return pegatina;
	}

	public int getIdProducto() {
		return idProducto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setPegatina(String pegatina) {
		this.pegatina = pegatina;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	public void guardarInformacion()
	{
		Gestor g = new Gestor();
		g.guardarCaja(this);
	}
}
