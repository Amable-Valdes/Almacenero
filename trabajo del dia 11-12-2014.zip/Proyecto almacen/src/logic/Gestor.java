package logic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Gestor {

	public static void main(String[] args) {
		Gestor g = new Gestor();
//		List<Pedido> carga = g.cargarPedidos();
//		for (Pedido p : carga)
//			p.muestra();
		g.pruebas();
	}
	
	private void pruebas() {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("INSERT INTO `pedidos` (`id_pedido`, `id_cliente`, `tipo_pago`, `tipo_envio`, `estado`, "
							+ "`direccion`, `precio`) VALUES (55, 5, 'tarjeta', 'normal', 'Por Recoger', 'Plaza Mayor n�2 2�C', 17.00)");
			ps.executeUpdate();
		System.out.println("A�adido");
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	private Connection crearConexion() {

		// Load the JDBC driver
		String driverName = "com.mysql.jdbc.Driver";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		// Create a connection to the database
		String db = "drnfrani_ips3";
		String url = "jdbc:mysql://31.22.4.75/" + db;
		String username = "drnfrani_almacen";
		String password = "carapan1234";
		try {
			return DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void cerraConexion(Connection con) {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Producto buscarProductoPorID(int id) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `productos` WHERE `id_producto`=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			rs.next();

			String nombre = rs.getString("nombre");
			String codigo = rs.getString("referencia");
			cerraConexion(con);
			return new Producto(id, nombre, codigo);

		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		cerraConexion(con);
		return null;
	}

	public ProductoPedido buscarProductoPedidoPorID(int idPedido, int idProducto) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `productosPedidos` WHERE `id_pedido`=? AND `id_producto`=?");
			ps.setInt(1, idPedido);
			ps.setInt(2, idProducto);
			ResultSet rs = ps.executeQuery();
			rs.next();

			Producto producto = buscarProductoPorID(idProducto);
			int cantidad = rs.getInt("cantidad");
			String estado = rs.getString("estado");
			cerraConexion(con);
			return new ProductoPedido(idPedido, idProducto, producto, cantidad,
					estado);

		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		cerraConexion(con);
		return null;
	}

	public List<Pedido> cargarPedidos() {
		List<Pedido> pedidos = new ArrayList<Pedido>();

		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `pedidos`");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idPedido = rs.getInt("id_pedido");
				String direccion = rs.getString("direccion");
				String estado = rs.getString("estado");
				List<ProductoPedido> listaProductos = buscarProductosAsociadosAPedido(idPedido);
				pedidos.add(new Pedido(idPedido, listaProductos, direccion,
						estado));
			}
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		cerraConexion(con);
		return pedidos;
	}

	private List<ProductoPedido> buscarProductosAsociadosAPedido(int idPedido) {
		List<ProductoPedido> productosPedidos = new ArrayList<ProductoPedido>();

		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `productosPedidos` WHERE `id_pedido`=?");
			ps.setInt(1, idPedido);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idProducto = rs.getInt("id_producto");
				Producto producto = buscarProductoPorID(idProducto);
				int cantidad = rs.getInt("cantidad");
				String estado = rs.getString("estado");
				productosPedidos.add(new ProductoPedido(idProducto, idPedido,
						producto, cantidad, estado));
			}
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		cerraConexion(con);
		return productosPedidos;
	}

	public void productoRecogido(int id_Pedido, int id_Producto) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("UPDATE `productosPedidos` SET estado='Recogido' WHERE id_Producto=? AND id_Pedido=?");
			ps.setInt(1, id_Producto);
			ps.setInt(2, id_Pedido);
			ps.executeUpdate();
			cerraConexion(con);
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void productoEmpaquetado(int id_Pedido, int id_Producto) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("UPDATE `productosPedidos` SET estado='Empaquetado' WHERE id_Producto=? AND id_Pedido=?");
			ps.setInt(1, id_Producto);
			ps.setInt(2, id_Pedido);
			ps.executeUpdate();
			cerraConexion(con);
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void cambiarEstadoPedido(Integer id, String estado) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("UPDATE `pedidos` SET estado=? WHERE `id_pedido`=?");
			ps.setString(1, estado);
			ps.setInt(2, id);
			ps.executeUpdate();
			cerraConexion(con);
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void generarAlbaran(String direccion, String date,
			Pedido pedidoSeleccionado) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("INSERT INTO `albaranes` (`id_pedido`, `fecha`, `estado`) "
							+ "VALUES (?, ?, ?);");
			
			ps.setInt(1, pedidoSeleccionado.getId());
			ps.setString(2, date);
			ps.setString(3, "Entregado al transportista");
			ps.executeUpdate();
			cerraConexion(con);
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public boolean pedidoTieneAlbaranAsignado(Integer id) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `albaranes` WHERE `id_pedido`=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				cerraConexion(con);
				return true;
			};
			
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		cerraConexion(con);
		return false;
	}

	public void enviarPedido(Integer id) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("UPDATE `pedidos` SET estado=? WHERE `id_pedido`=?");
			ps.setString(1, ProductoPedido.ENVIADO);
			ps.setInt(2, id);
			ps.executeUpdate();
			cerraConexion(con);
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void guardarCaja(Caja caja) {
			Connection con = crearConexion();
			try {
				PreparedStatement ps = con
						.prepareStatement("INSERT INTO `cajas` (`pegatina`, `id_producto`, `cantidad`) "
								+ "VALUES (?, ?, ?);");
				
				ps.setString(1, caja.getPegatina());
				ps.setInt(2, caja.getIdProducto());
				ps.setInt(3, caja.getCantidad());
				ps.executeUpdate();
				cerraConexion(con);
			} catch (SQLException e) {
				System.out.println("Error: " + e.getMessage());
			}
	}
	
	public String buscarCaja(int idProducto,int cantidad) {
		Connection con = crearConexion();
		try {
			PreparedStatement ps = con
					.prepareStatement("SELECT * FROM `cajas` WHERE `id_producto`=? and `cantidad`=?");
			ps.setInt(1, idProducto);
			ps.setInt(2, cantidad);
			ResultSet rs = ps.executeQuery();
			rs.next();
			String pegatina = rs.getString("pegatina");
			cerraConexion(con);
			return pegatina;
		} catch (SQLException e) {
			System.out.println("Error: " + e.getMessage());
		}
		return "";
	}
}
