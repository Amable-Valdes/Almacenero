package logic;

import java.util.ArrayList;
import java.util.List;

public class Pedido {

	private Integer id;
	private List<ProductoPedido> productos = new ArrayList<ProductoPedido>();
	private String direccion;
	private String estado;

	public Pedido(Integer id, String direccion) {
		this.id = id;
		this.direccion = direccion;
	}

	public Pedido(Integer id, List<ProductoPedido> productos, String direccion, String estado) {
		this.id = id;
		this.productos = productos;
		this.direccion = direccion;
		this.estado = estado;
		comprobarEstado();
	}

	public void add(ProductoPedido producto) {
		productos.add(producto);
	}

	public void remove(ProductoPedido producto) {
		productos.remove(producto);
	}

	public List<ProductoPedido> getProductos() {
		return productos;
	}

	public void setProductos(List<ProductoPedido> listaProductos) {
		this.productos = listaProductos;
	}

	public Integer getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "N� pedido: " + id + " - Cantidad: " + getCantidadProductos();
	}

	public void muestra() {
		System.out.println("El pedido " + getId()
				+ " tiene los siguientes productos: ");
		for (Object producto : getProductos())
			System.out.println("----->" + producto.toString());
	}

	public String getEstado() {
		return estado;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public void comprobarEstado()
	{
		// �Ha sido recogido?
		Gestor g = new Gestor();
		String estadoAnterior = estado;
		
		for (ProductoPedido producto : getProductos()) {
			if (producto.getEstado().equals(ProductoPedido.EMPAQUETADO_NO_ENVIADO)) {
				if(todosEmpaquetados())
				{
					estado = ProductoPedido.EMPAQUETADO_NO_ENVIADO;
				}
			}
		}
		
		for (ProductoPedido producto : getProductos()) {
			if (producto.getEstado().equals(ProductoPedido.RECOGIDO)) {
				estado = ProductoPedido.RECOGIDO;
			}
		}
		
		for (ProductoPedido producto : getProductos()) {
			if (producto.getEstado().equals(ProductoPedido.POR_RECOGER)) {
				estado = ProductoPedido.POR_RECOGER;
			}
		}
		
		if(g.pedidoTieneAlbaranAsignado(id))
		{
			estado = ProductoPedido.ENVIADO;
		}
		
		if(!estadoAnterior.equals(estado)){
			g.cambiarEstadoPedido(id,estado);
		}
//		for (ProductoPedido producto : getProductos()) {
//			if (producto.getEstado().equals(ProductoPedido.EMPAQUETADO)) {
//				estado = ProductoPedido.EMPAQUETADO;
//			}
//		}
	}
	
	public boolean todosEmpaquetados()
	{
		for(ProductoPedido p : productos)
		{
			if(!p.getEstado().equals(ProductoPedido.EMPAQUETADO_NO_ENVIADO))
			{
				return false;
			}
		}
		return true;
	}
	
	public void finalizar_Y_Enviar()
	{
		estado=ProductoPedido.ENVIADO;
		Gestor g = new Gestor();
		g.enviarPedido(id);
	}
	
//	private String calcularEstado()
//	{
//		// �Ha sido recogido?
//				String estado = null;
//				for (ProductoPedido producto : getProductos()) {
//					if (producto.getEstado().equals(ProductoPedido.POR_RECOGER)) {
//						estado = ProductoPedido.POR_RECOGER;
//					}
//				}
//				for (ProductoPedido producto : getProductos()) {
//					if (producto.getEstado().equals(ProductoPedido.RECOGIDO)) {
//						estado = ProductoPedido.RECOGIDO;
//					}
//				}
//				for (ProductoPedido producto : getProductos()) {
//					if (producto.getEstado().equals(ProductoPedido.EMPAQUETADO)) {
//						estado = ProductoPedido.EMPAQUETADO;
//					}
//				}
//				return estado;
//	}

	public int getCantidadProductos() {
		int cantidad = 0;
		for (ProductoPedido p : productos)
		{
			cantidad = cantidad + p.getCantidad();
		}
		return cantidad;
	}
	
//	public List<ProductoPedido> getBultos() {
//		List<ProductoPedido> bultos = new ArrayList<ProductoPedido>();
//		for (Producto p : productos) {
//			boolean yaAnnadido = false;
//			for(ProductoPedido b : bultos)
//			{
//				if(p.getCode().equals(b.getProductos().get(0).getCode()))
//				{
//					yaAnnadido = true;
//				}
//			}
//			if(!yaAnnadido){
//				List<Producto> bultoEspecifico = new ArrayList<Producto>();
//				for (Producto producto : productos) {
//					if (p.getCode().equals(producto.getCode())) {
//						bultoEspecifico.add(producto);
//					}
//				}
//				bultos.add(new ProductoPedido(bultoEspecifico));
//			}
//		}
//		return bultos;
//	}
}
