package logic;


public class ProductoPedido {

	public static final String RECOGIDO = "Recogido";
	public static final String POR_RECOGER = "Por Recoger";
	public static final String EMPAQUETADO_NO_ENVIADO = "Empaquetado";
	public static final String ENVIADO = "Enviado";

	private int id_Producto;
	private int id_Pedido;
	private Producto producto;
	private int cantidad;
	private String estado;
	
	public ProductoPedido(int idProd, int idPed, Producto producto, int cantidad, String estado) {
		super();
		this.id_Producto = idProd;
		this.id_Pedido = idPed;
		this.producto = producto;
		this.cantidad = cantidad;
		this.estado = estado;
	}

	public Producto getProductos() {
		return producto;
	}

	public int getCantidad() {
		return cantidad;
	}
	
	public int getId_Producto() {
		return id_Producto;
	}

	public int getId_Pedido() {
		return id_Pedido;
	}

	public String getEstado() {
		return estado;
	}
	
	public void recoger()
	{
		
		Gestor g = new Gestor();
		g.productoRecogido(id_Pedido, id_Producto);
		this.estado = ProductoPedido.RECOGIDO;
	}
	
//	public void recogerXUnidades(int unidades)
//	{
//		
//		Gestor g = new Gestor();
//		g.unidadesXRecogidas(id_Pedido, id_Producto, unidades);
//		cantidad = cantidad-unidades;
//	}
	
	public void empaquetar()
	{
		
		Gestor g = new Gestor();
		g.productoEmpaquetado(id_Pedido, id_Producto);
		this.estado = ProductoPedido.EMPAQUETADO_NO_ENVIADO;
	}
	
//	public void empaquetarXUnidades(int unidades)
//	{
//		
//		Gestor g = new Gestor();
//		g.unidadesXEmpaquetadas(id_Pedido, id_Producto, unidades);
//		cantidad = cantidad-unidades;
//	}
	
	@Override
	public String toString() {
		return "ProductoPedido [id_Producto= " + id_Producto + ", id_Pedido="
				+ id_Pedido + ", producto= (((" + producto + "))), cantidad="
				+ cantidad + ", estado=" + estado + "]";
	}
	
}
