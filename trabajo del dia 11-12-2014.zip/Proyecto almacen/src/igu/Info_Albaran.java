package igu;

import igu.util.ModeloNoEditable;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import logic.Albaran;
import logic.Gestor;
import logic.ProductoPedido;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Info_Albaran extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel lb_CodigoAlbaran_Y_Fecha;
	private JPanel panel_Intro;
	private JPanel panel_Informacion;
	private JLabel lb_Destino;
	private JPanel panel_Productos;
	private JLabel lb_ProductosPedido;
	private JScrollPane panel_Scroll;
	private JTable tabla_Productos;
	private JButton bt_Salir;
	private JPanel panel_Salir;
	
	private Albaran albaran;
	private ModeloNoEditable modelo;

	/**
	 * Create the dialog.
	 */
	public Info_Albaran(Albaran albaran) {
		this.albaran= albaran;
		setBounds(100, 100, 525, 345);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(10, 10));
		contentPanel.add(getPanel_Intro(), BorderLayout.NORTH);
		contentPanel.add(getPanel_Informacion(), BorderLayout.CENTER);
		getContentPane().add(getPanel_Salir(), BorderLayout.SOUTH);
		cargarInformacion();
		setTitle("Informaci�n Albar�n");
	}

	private JLabel getLb_CodigoAlbaran_Y_Fecha() {
		if (lb_CodigoAlbaran_Y_Fecha == null) {
			lb_CodigoAlbaran_Y_Fecha = new JLabel();
			lb_CodigoAlbaran_Y_Fecha.setFont(new Font("Tahoma", Font.PLAIN, 14));
		}
		return lb_CodigoAlbaran_Y_Fecha;
	}
	private JPanel getPanel_Intro() {
		if (panel_Intro == null) {
			panel_Intro = new JPanel();
			panel_Intro.setLayout(new BorderLayout(10, 10));
			panel_Intro.add(getLb_CodigoAlbaran_Y_Fecha());
		}
		return panel_Intro;
	}
	private JPanel getPanel_Informacion() {
		if (panel_Informacion == null) {
			panel_Informacion = new JPanel();
			panel_Informacion.setLayout(new BorderLayout(10, 10));
			panel_Informacion.add(getLb_Destino(), BorderLayout.NORTH);
			panel_Informacion.add(getPanel_Productos(), BorderLayout.CENTER);
		}
		return panel_Informacion;
	}
	private JLabel getLb_Destino() {
		if (lb_Destino == null) {
			lb_Destino = new JLabel("Destino:");
			lb_Destino.setFont(new Font("Tahoma", Font.PLAIN, 14));
		}
		return lb_Destino;
	}
	private JPanel getPanel_Productos() {
		if (panel_Productos == null) {
			panel_Productos = new JPanel();
			panel_Productos.setLayout(new BorderLayout(10, 5));
			panel_Productos.add(getLb_ProductosPedido(), BorderLayout.NORTH);
			panel_Productos.add(getPanel_Scroll(), BorderLayout.CENTER);
		}
		return panel_Productos;
	}
	private JLabel getLb_ProductosPedido() {
		if (lb_ProductosPedido == null) {
			lb_ProductosPedido = new JLabel("Productos:");
			lb_ProductosPedido.setFont(new Font("Tahoma", Font.PLAIN, 14));
		}
		return lb_ProductosPedido;
	}
	private JScrollPane getPanel_Scroll() {
		if (panel_Scroll == null) {
			panel_Scroll = new JScrollPane();
			panel_Scroll.setViewportView(getTabla_Productos());
		}
		return panel_Scroll;
	}
	private JTable getTabla_Productos() {
		if (tabla_Productos == null) {
			String[] columnas = { "Nombre", "C�digo", "Cantidad", "Caja" };
			modelo = new ModeloNoEditable(columnas, 0);
			tabla_Productos = new JTable(modelo);
			tabla_Productos.setRowHeight(20);
			tabla_Productos.getTableHeader().setReorderingAllowed(false);
		}
		return tabla_Productos;
	}
	private JButton getBt_Salir() {
		if (bt_Salir == null) {
			bt_Salir = new JButton("Salir");
			bt_Salir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					salir();
				}
			});
		}
		return bt_Salir;
	}
	
	private void salir(){
		this.dispose();
	}
	
	private JPanel getPanel_Salir() {
		if (panel_Salir == null) {
			panel_Salir = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel_Salir.getLayout();
			flowLayout.setVgap(10);
			flowLayout.setHgap(10);
			flowLayout.setAlignment(FlowLayout.RIGHT);
			panel_Salir.add(getBt_Salir());
		}
		return panel_Salir;
	}
	
	private void cargarInformacion()
	{
		lb_CodigoAlbaran_Y_Fecha.setText("C\u00F3digo del Albar\u00E1n: "+ albaran.getCodigo() + " con fecha "+ albaran.getFecha());
		lb_Destino.setText("Destino: "+ albaran.getDestino());
		a�adirDatos();
		
	}
	
	private void a�adirDatos(){
		modelo.getDataVector().clear();
		modelo.fireTableDataChanged();
		Object[] nuevaFila = new Object[4];
		Gestor g = new Gestor();
		for(ProductoPedido p : albaran.getPedido().getProductos())
		{
			nuevaFila[0] = p.getProductos().getName();
			nuevaFila[1] = p.getProductos().getCode();
			nuevaFila[2] = p.getCantidad();
			nuevaFila[3] = g.buscarCaja(p.getId_Producto(),p.getCantidad());
			modelo.addRow(nuevaFila);
		}
	}
}
