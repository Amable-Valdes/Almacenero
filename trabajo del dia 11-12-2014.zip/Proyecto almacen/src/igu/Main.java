package igu;

import igu.util.ModeloNoEditable;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import logic.Gestor;
import logic.Pedido;
import logic.ProductoPedido;

public class Main extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel panel_contenedor;
	private JButton bt_Recoger;
	private JPanel panel_Botones;
	private JButton bt_Empaquetar;
	private JPanel panel_TablaPedidos;
	private JScrollPane panel_scroll;
	private JTable tabla_Pedidos;
	private JPanel panel_BotonRecoger;
	private JPanel panel_BotonEmpaquetar;
	
	private ModeloNoEditable modelo;
	private Pedido pedidoSeleccionado;
	private List<Pedido> listaPedidos;

	public Pedido getPedidoSeleccionado() {
		return pedidoSeleccionado;
	}
	
	private Pedido findPedidoByID(int id)
	{
		for(Pedido p : listaPedidos)
		{
			if(p.getId() == id)
				return p;
		}
		return null;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("PDA - Inicio");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 333, 465);
		panel_contenedor = new JPanel();
		panel_contenedor.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel_contenedor.setLayout(new BorderLayout(10, 20));
		setContentPane(panel_contenedor);
		panel_contenedor.add(getPanel_Botones(), BorderLayout.EAST);
		panel_contenedor.add(getPanel_TablaPedidos(), BorderLayout.CENTER);
		Gestor g = new Gestor();
		listaPedidos = g.cargarPedidos();
		a�adirDatos();
		bt_Recoger.setEnabled(false);
		bt_Empaquetar.setEnabled(false);
	}

	private JButton getBt_Recoger() {
		if (bt_Recoger == null) {
			bt_Recoger = new JButton("Recoger Pedido");
			bt_Recoger.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					abrirPantallaRecogida();
				}
			});
		}
		return bt_Recoger;
	}
	
	private void abrirPantallaRecogida()
	{
		Recogida j = new Recogida(this);
		j.setVisible(true);
	}
	
	private JPanel getPanel_Botones() {
		if (panel_Botones == null) {
			panel_Botones = new JPanel();
			panel_Botones.setLayout(new GridLayout(0, 1, 0, 0));
			panel_Botones.add(getPanel_BotonRecoger());
			panel_Botones.add(getPanel_BotonEmpaquetar());
		}
		return panel_Botones;
	}
	private JButton getBt_Empaquetar() {
		if (bt_Empaquetar == null) {
			bt_Empaquetar = new JButton("Empaquetar Pedido");
			bt_Empaquetar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					abrirPantallaEmpaquetado();
				}
			});
		}
		return bt_Empaquetar;
	}
	
	private void abrirPantallaEmpaquetado()
	{
		Empaquetado j = new Empaquetado(this);
		j.setVisible(true);
	}
	
	private JPanel getPanel_TablaPedidos() {
		if (panel_TablaPedidos == null) {
			panel_TablaPedidos = new JPanel();
			panel_TablaPedidos.setLayout(new BorderLayout(0, 0));
			panel_TablaPedidos.add(getPanel_scroll());
		}
		return panel_TablaPedidos;
	}
	private JScrollPane getPanel_scroll() {
		if (panel_scroll == null) {
			panel_scroll = new JScrollPane();
			panel_scroll.setViewportView(getTabla_Pedidos());
		}
		return panel_scroll;
	}
	private JTable getTabla_Pedidos() {
		if (tabla_Pedidos == null) {
			String[] columnas = { "id", "Productos", "Estado" };
			modelo = new ModeloNoEditable(columnas, 0);
			tabla_Pedidos = new JTable(modelo);
			ajustarAnchoColumnas();
			tabla_Pedidos.setRowHeight(20);
			tabla_Pedidos.getTableHeader().setReorderingAllowed(false);
			
			tabla_Pedidos.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseReleased(MouseEvent e) {
					if (tabla_Pedidos.getSelectedRow() != -1) {
						if(modelo.getValueAt(tabla_Pedidos.getSelectedRow(), 2).equals(ProductoPedido.RECOGIDO)
								|| modelo.getValueAt(tabla_Pedidos.getSelectedRow(), 2).equals(ProductoPedido.EMPAQUETADO_NO_ENVIADO)){
							bt_Empaquetar.setEnabled(true);
							bt_Recoger.setEnabled(false);
						}else{
							bt_Recoger.setEnabled(true);
							bt_Empaquetar.setEnabled(false);
						}
						pedidoSeleccionado = findPedidoByID((int) modelo.getValueAt(tabla_Pedidos.getSelectedRow(), 0));
					}
					else
					{
						bt_Recoger.setEnabled(false);
						bt_Empaquetar.setEnabled(false);
					}
				}
			});
		}
		return tabla_Pedidos;
	}
	
	private void a�adirDatos(){
		modelo.getDataVector().clear();
		modelo.fireTableDataChanged();
		Object[] nuevaFila = new Object[3];
		for(Pedido p : listaPedidos)
		{
			if(p.getEstado().equals(ProductoPedido.POR_RECOGER) || 
					p.getEstado().equals(ProductoPedido.RECOGIDO)|| 
					p.getEstado().equals(ProductoPedido.EMPAQUETADO_NO_ENVIADO)){
			nuevaFila[0] = p.getId();
			nuevaFila[1] = p.getCantidadProductos();
			nuevaFila[2] = p.getEstado();
			modelo.addRow(nuevaFila);
			}
		}
	}
	
	private void ajustarAnchoColumnas(){
		int[] anchos = {25, 150, 100};
		for(int i = 0; i < tabla_Pedidos.getColumnCount(); i++)
			tabla_Pedidos.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
	}
	
	private JPanel getPanel_BotonRecoger() {
		if (panel_BotonRecoger == null) {
			panel_BotonRecoger = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel_BotonRecoger.getLayout();
			flowLayout.setVgap(50);
			panel_BotonRecoger.add(getBt_Recoger());
		}
		return panel_BotonRecoger;
	}
	private JPanel getPanel_BotonEmpaquetar() {
		if (panel_BotonEmpaquetar == null) {
			panel_BotonEmpaquetar = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel_BotonEmpaquetar.getLayout();
			flowLayout.setVgap(50);
			panel_BotonEmpaquetar.add(getBt_Empaquetar());
		}
		return panel_BotonEmpaquetar;
	}

	public void actualizar() {
		for(Pedido p : listaPedidos)
			p.comprobarEstado();
		a�adirDatos();
		bt_Empaquetar.setEnabled(false);
		bt_Recoger.setEnabled(false);
	}
}
