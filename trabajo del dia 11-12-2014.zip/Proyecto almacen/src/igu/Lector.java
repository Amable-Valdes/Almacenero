package igu;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import logic.Caja;
import logic.ProductoPedido;

public class Lector extends JDialog {

	private static final long serialVersionUID = 1L;
	public final static int MODO_RECOGIDA = 0;
	public final static int MODO_EMPAQUETADO = 1;
	private final JPanel contentPanel = new JPanel();
	private JPanel panel_Boton;
	private JButton bt_Introducir;
	private JPanel panel_Code;
	private JTextField txF_Code;
	private JTextArea txA_Info;
	
	private Recogida recogida;
	private Empaquetado empaquetado;
	private ProductoPedido producto;
	private int modoEjecucion;

	public Lector(Recogida recogida) {
		setModal(true);
		modoEjecucion = MODO_RECOGIDA;
		setBounds(100, 100, 200, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(10, 10));
		contentPanel.add(getPanel_Boton(), BorderLayout.SOUTH);
		contentPanel.add(getPanel_Code(), BorderLayout.CENTER);
		contentPanel.add(getTxA_Info(), BorderLayout.NORTH);
		this.recogida = recogida;
		producto = recogida.getProductoPedidoSeleccionado();
		setTitle("Lector");
	}

	public Lector(Empaquetado empaquetado) {
		setModal(true);
		modoEjecucion = MODO_EMPAQUETADO;
		setBounds(100, 100, 200, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(10, 10));
		contentPanel.add(getPanel_Boton(), BorderLayout.SOUTH);
		contentPanel.add(getPanel_Code(), BorderLayout.CENTER);
		contentPanel.add(getTxA_Info(), BorderLayout.NORTH);
		this.empaquetado = empaquetado;
		producto = empaquetado.getProductoPedidoSeleccionado();
	}

	private JPanel getPanel_Boton() {
		if (panel_Boton == null) {
			panel_Boton = new JPanel();
			panel_Boton.add(getBt_Introducir());
		}
		return panel_Boton;
	}
	
	private JButton getBt_Introducir() {
		if (bt_Introducir == null) {
			bt_Introducir = new JButton("Introducir");
			bt_Introducir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String textoIntroducido = txF_Code.getText();
					if(textoIntroducido.equals(producto.getProductos().getCode()))
					{
						JOptionPane.showMessageDialog(null,
								"Codigo de barras CORRECTO. Procesando...");
						if(modoEjecucion == MODO_RECOGIDA){
							producto.recoger();
							recogida.actualizar();
						}else{
							producto.empaquetar();
							Caja caja = new Caja(producto);
							caja.guardarInformacion();
							JOptionPane.showMessageDialog(null,"Caja guardada, imprimiendo pegatina... Pegatina: " + caja.getPegatina() + ". Procesando...");
							empaquetado.actualizar();
						}
						
						JOptionPane.showMessageDialog(null,
								"Producto "+ ((modoEjecucion == MODO_RECOGIDA)? "RECOGIDO":"EMPAQUETADO"));
						
						cerrar();
					}else
					{
						JOptionPane.showMessageDialog(null,
								"El codigo de barras introducido es incorrecto, vuelva a introducirlo");
						txF_Code.setText("");
					}
				}
			});
		}
		return bt_Introducir;
	}
	
	private void cerrar()
	{
		this.dispose();
	}
	
	private JPanel getPanel_Code() {
		if (panel_Code == null) {
			panel_Code = new JPanel();
			FlowLayout flowLayout = (FlowLayout) panel_Code.getLayout();
			flowLayout.setVgap(20);
			panel_Code.add(getTxF_Code());
		}
		return panel_Code;
	}
	private JTextField getTxF_Code() {
		if (txF_Code == null) {
			txF_Code = new JTextField();
			txF_Code.setColumns(10);
		}
		return txF_Code;
	}
	private JTextArea getTxA_Info() {
		if (txA_Info == null) {
			txA_Info = new JTextArea();
			txA_Info.setEditable(false);
			txA_Info.setLineWrap(true);
			txA_Info.setWrapStyleWord(true);
			txA_Info.setText("Introduzca el c\u00F3digo del producto");
		}
		return txA_Info;
	}
}
