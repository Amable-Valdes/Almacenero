package igu;

import igu.util.ModeloNoEditable;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import logic.Albaran;
import logic.Gestor;
import logic.Pedido;
import logic.ProductoPedido;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Empaquetado extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JPanel panel_Tabla;
	private JScrollPane scrollPane;
	private JTable tabla_Productos;
	private JPanel panel_Opciones;
	private JPanel panel_Boton;
	private JButton bt_Empaquetar;
	private JPanel panel_Unidades;
	private JPanel panel_Texto;
	private JLabel lb_Unidades;
	private JPanel panel_Num;
	private JTextField txF_Unidades;
	private JPanel panel_Finalizar;
	private JButton bt_Finalizar;

	private Main principal;
	private ModeloNoEditable modelo;
	private Pedido pedidoSeleccionado;
	private List<ProductoPedido> listaBultos;
	private ProductoPedido productoPedidoSeleccionado;
	
	public ProductoPedido getProductoPedidoSeleccionado() {
		return productoPedidoSeleccionado;
	}

	/**
	 * Create the dialog.
	 */
	public Empaquetado(Main main) {
		setModal(true);
		setBounds(100, 100, 333, 465);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		contentPanel.add(getPanel_Tabla());
		contentPanel.add(getPanel_Opciones(), BorderLayout.EAST);
		
		principal = main;
		pedidoSeleccionado = main.getPedidoSeleccionado();
		listaBultos = pedidoSeleccionado.getProductos();
		a�adirDatos();
		actualizarBotones();
		setTitle("Empaquetando - PDA");
	}

	private JPanel getPanel_Tabla() {
		if (panel_Tabla == null) {
			panel_Tabla = new JPanel();
			panel_Tabla.setLayout(new BorderLayout(0, 0));
			panel_Tabla.add(getScrollPane());
		}
		return panel_Tabla;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTabla_Productos());
		}
		return scrollPane;
	}
	private JTable getTabla_Productos() {
		if (tabla_Productos == null) {
			String[] columnas = { "Producto", "Cantidad", "Codigo" };
			modelo = new ModeloNoEditable(columnas, 0);
			tabla_Productos = new JTable(modelo);
			ajustarAnchoColumnas();
			tabla_Productos.setRowHeight(20);
			tabla_Productos.getTableHeader().setReorderingAllowed(false);
			
			tabla_Productos.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseReleased(MouseEvent e) {
					if (tabla_Productos.getSelectedRow() != -1) {
						productoPedidoSeleccionado = findProductoPedidoByCode((String) modelo.getValueAt(tabla_Productos.getSelectedRow(), 2));
						bt_Empaquetar.setEnabled(true);
					}else
					{
						bt_Empaquetar.setEnabled(false);
					}
				}
			});
		}
		return tabla_Productos;
	}
	
	private void a�adirDatos(){
		modelo.getDataVector().clear();
		modelo.fireTableDataChanged();
		Object[] nuevaFila = new Object[3];
		for(ProductoPedido p : listaBultos)
		{
			if(p.getEstado().equals(ProductoPedido.RECOGIDO))
			{
				nuevaFila[0] = p.getProductos().getName();
				nuevaFila[1] = p.getCantidad();
				nuevaFila[2] = p.getProductos().getCode();
				modelo.addRow(nuevaFila);
			}
		}
	}
	
	private ProductoPedido findProductoPedidoByCode(String codigo) {
		for(ProductoPedido p : listaBultos)
		{
			if(p.getProductos().getCode().equals(codigo))
				return p;
		}
		return null;
	}
	
	private void ajustarAnchoColumnas(){
		int[] anchos = {100,50,100};
		for(int i = 0; i < tabla_Productos.getColumnCount(); i++)
			tabla_Productos.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
	}
	
	private JPanel getPanel_Opciones() {
		if (panel_Opciones == null) {
			panel_Opciones = new JPanel();
			panel_Opciones.setLayout(new GridLayout(0, 1, 0, 0));
			panel_Opciones.add(getPanel_Boton());
			panel_Opciones.add(getPanel_Unidades());
			panel_Opciones.add(getPanel_Finalizar());
		}
		return panel_Opciones;
	}
	private JPanel getPanel_Boton() {
		if (panel_Boton == null) {
			panel_Boton = new JPanel();
			panel_Boton.add(getBt_Empaquetar());
		}
		return panel_Boton;
	}
	
	private void abrirLector()
	{
		Lector l = new Lector(this);
		l.setVisible(true);
	}
	
	private JButton getBt_Empaquetar() {
		if (bt_Empaquetar == null) {
			bt_Empaquetar = new JButton("Meter en caja");
			bt_Empaquetar.setEnabled(false);
			bt_Empaquetar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					abrirLector();
				}
			});
		}
		return bt_Empaquetar;
	}
	private JPanel getPanel_Unidades() {
		if (panel_Unidades == null) {
			panel_Unidades = new JPanel();
			panel_Unidades.setLayout(new BorderLayout(0, 0));
			panel_Unidades.add(getPanel_Texto(), BorderLayout.NORTH);
			panel_Unidades.add(getPanel_Num());
		}
		return panel_Unidades;
	}
	private JPanel getPanel_Texto() {
		if (panel_Texto == null) {
			panel_Texto = new JPanel();
			panel_Texto.add(getLb_Unidades());
		}
		return panel_Texto;
	}
	private JLabel getLb_Unidades() {
		if (lb_Unidades == null) {
			lb_Unidades = new JLabel("n\u00BA Unidades");
		}
		return lb_Unidades;
	}
	private JPanel getPanel_Num() {
		if (panel_Num == null) {
			panel_Num = new JPanel();
			panel_Num.add(getTxF_Unidades());
		}
		return panel_Num;
	}
	private JTextField getTxF_Unidades() {
		if (txF_Unidades == null) {
			txF_Unidades = new JTextField();
			txF_Unidades.setText("0");
			txF_Unidades.setColumns(10);
		}
		return txF_Unidades;
	}
	private JPanel getPanel_Finalizar() {
		if (panel_Finalizar == null) {
			panel_Finalizar = new JPanel();
			panel_Finalizar.add(getBt_Finalizar());
		}
		return panel_Finalizar;
	}
	private JButton getBt_Finalizar() {
		if (bt_Finalizar == null) {
			bt_Finalizar = new JButton("Finalizar");
			bt_Finalizar.setEnabled(false);
			bt_Finalizar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Gestor g = new Gestor();
					
					String patron = "dd/MM/yyyy";
				    SimpleDateFormat formato = new SimpleDateFormat(patron);
					g.generarAlbaran(pedidoSeleccionado.getDireccion(), formato.format(new Date()), pedidoSeleccionado);
					pedidoSeleccionado.finalizar_Y_Enviar();
					JOptionPane.showMessageDialog(null,
							"Albar�n generado, se mostrar� dicho albar�n a continuaci�n");
					actualizar();
					JDialog n = new Info_Albaran(new Albaran(1, pedidoSeleccionado.getId()
							+"000"+ pedidoSeleccionado.getCantidadProductos() +"", pedidoSeleccionado.getDireccion(),
							formato.format(new Date()), pedidoSeleccionado));
					n.setVisible(true);
					salir();
				}
			});
		}
		return bt_Finalizar;
	}
	
	private void salir()
	{
		this.dispose();
	}
	
	public void actualizar() {
		a�adirDatos();
		principal.actualizar();
		actualizarBotones();
	}
	
	private void actualizarBotones()
	{
		if(tabla_Productos.getRowCount() == 0)
		{
			bt_Finalizar.setEnabled(true);
			bt_Empaquetar.setEnabled(false);
		}else
		{
			bt_Finalizar.setEnabled(false);
			bt_Empaquetar.setEnabled(true);
		}
	}
}
