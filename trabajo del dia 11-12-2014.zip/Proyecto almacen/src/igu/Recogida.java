package igu;

import igu.util.ModeloNoEditable;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import logic.Pedido;
import logic.ProductoPedido;

public class Recogida extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JPanel panel_Tabla;
	private JScrollPane panelScroll;
	private JTable tabla_Productos;
	private JPanel panel_Opciones;
	private JPanel panel_Boton;
	private JButton bt_Recoger;
	private JPanel panel_Unidades;
	private JLabel lb_Unidades;
	private JTextField txF_Unidades;
	private JPanel panel_Texto;
	private JPanel panel_Num;
	
	private Main principal;
	private ModeloNoEditable modelo;
	private Pedido pedidoSeleccionado;
	private List<ProductoPedido> listaBultos;
	private ProductoPedido productoPedidoSeleccionado;

	public ProductoPedido getProductoPedidoSeleccionado() {
		return productoPedidoSeleccionado;
	}

	/**
	 * Create the dialog.
	 */
	public Recogida(Main main) {
		setModal(true);
		setBounds(100, 100, 333, 465);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		contentPanel.add(getPanel_Tabla());
		contentPanel.add(getPanel_Opciones(), BorderLayout.EAST);
		
		principal = main;
		pedidoSeleccionado = main.getPedidoSeleccionado();
		listaBultos = pedidoSeleccionado.getProductos();
		a�adirDatos();
		setTitle("Recogiendo - PDA");
	}

	private JPanel getPanel_Tabla() {
		if (panel_Tabla == null) {
			panel_Tabla = new JPanel();
			panel_Tabla.setLayout(new BorderLayout(0, 0));
			panel_Tabla.add(getPanelScroll());
		}
		return panel_Tabla;
	}
	private JScrollPane getPanelScroll() {
		if (panelScroll == null) {
			panelScroll = new JScrollPane();
			panelScroll.setViewportView(getTabla_Productos());
		}
		return panelScroll;
	}
	
	private JTable getTabla_Productos() {
		if (tabla_Productos == null) {
			String[] columnas = { "Producto", "Cantidad", "Codigo" };
			modelo = new ModeloNoEditable(columnas, 0);
			tabla_Productos = new JTable(modelo);
			ajustarAnchoColumnas();
			tabla_Productos.setRowHeight(20);
			tabla_Productos.getTableHeader().setReorderingAllowed(false);
			
			tabla_Productos.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseReleased(MouseEvent e) {
					if (tabla_Productos.getSelectedRow() != -1) {
						productoPedidoSeleccionado = findProductoPedidoByCode((String) modelo.getValueAt(tabla_Productos.getSelectedRow(), 2));
						bt_Recoger.setEnabled(true);
					}else
					{
						bt_Recoger.setEnabled(false);
					}
				}
			});
		}
		return tabla_Productos;
	}
	
	private ProductoPedido findProductoPedidoByCode(String codigo) {
		for(ProductoPedido p : listaBultos)
		{
			if(p.getProductos().getCode().equals(codigo))
				return p;
		}
		return null;
	}
	
	private void a�adirDatos(){
		modelo.getDataVector().clear();
		modelo.fireTableDataChanged();
		Object[] nuevaFila = new Object[3];
		for(ProductoPedido p : listaBultos)
		{
			if(p.getEstado().equals(ProductoPedido.POR_RECOGER))
			{
				nuevaFila[0] = p.getProductos().getName();
				nuevaFila[1] = p.getCantidad();
				nuevaFila[2] = p.getProductos().getCode();
				modelo.addRow(nuevaFila);
			}
		}
	}
	
	private void ajustarAnchoColumnas(){
		int[] anchos = {100,50,100};
		for(int i = 0; i < tabla_Productos.getColumnCount(); i++)
			tabla_Productos.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
	}
	
	private JPanel getPanel_Opciones() {
		if (panel_Opciones == null) {
			panel_Opciones = new JPanel();
			panel_Opciones.setLayout(new GridLayout(0, 1, 0, 0));
			panel_Opciones.add(getPanel_Boton());
			panel_Opciones.add(getPanel_Unidades());
		}
		return panel_Opciones;
	}
	private JPanel getPanel_Boton() {
		if (panel_Boton == null) {
			panel_Boton = new JPanel();
			panel_Boton.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20));
			panel_Boton.add(getBt_Recoger());
		}
		return panel_Boton;
	}
	private JButton getBt_Recoger() {
		if (bt_Recoger == null) {
			bt_Recoger = new JButton("Recoger");
			bt_Recoger.setEnabled(false);
			bt_Recoger.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					abrirLector();
				}
			});
		}
		return bt_Recoger;
	}
	
	private void abrirLector()
	{
		Lector l = new Lector(this);
		l.setVisible(true);
	}
	
	private JPanel getPanel_Unidades() {
		if (panel_Unidades == null) {
			panel_Unidades = new JPanel();
			panel_Unidades.setLayout(new BorderLayout(0, 0));
			panel_Unidades.add(getPanel_Texto(), BorderLayout.NORTH);
			panel_Unidades.add(getPanel_Num(), BorderLayout.CENTER);
		}
		return panel_Unidades;
	}
	private JLabel getLb_Unidades() {
		if (lb_Unidades == null) {
			lb_Unidades = new JLabel("n\u00BA Unidades");
		}
		return lb_Unidades;
	}
	private JTextField getTxF_Unidades() {
		if (txF_Unidades == null) {
			txF_Unidades = new JTextField();
			txF_Unidades.setText("0");
			txF_Unidades.setColumns(10);
		}
		return txF_Unidades;
	}
	private JPanel getPanel_Texto() {
		if (panel_Texto == null) {
			panel_Texto = new JPanel();
			panel_Texto.add(getLb_Unidades());
		}
		return panel_Texto;
	}
	private JPanel getPanel_Num() {
		if (panel_Num == null) {
			panel_Num = new JPanel();
			panel_Num.add(getTxF_Unidades());
		}
		return panel_Num;
	}

	public void actualizar() {
		a�adirDatos();
		principal.actualizar();
		if(tabla_Productos.getRowCount() == 0)
			salir();
	}
	
	private void salir()
	{
		this.dispose();
	}
}
